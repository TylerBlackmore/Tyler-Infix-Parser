#include "InfixParser.h"
#include <cmath>
#include <cstdlib>
using namespace std;

bool InfixParser::isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '%' || c == '/' || c == '^';
}

int InfixParser::precedence(char op) {
    switch (op) {
    case '^':
        return 3;
    case '*':
    case '/':
    case '%':
        return 2;
    case '+':
    case '-':
        return 1;
    default:
        return -1;
    }
}

vector<string> InfixParser::tokenize(const string& expression) {
    vector<string> tokens;
    string token = "";

    for (char c : expression) {
        if (c == ' ')
            continue;
        if (isOperator(c) || c == '(' || c == ')') {
            if (!token.empty()) {
                tokens.push_back(token);
                token = "";
            }
            tokens.push_back(string(1, c));
        }
        else {
            token += c;
        }
    }

    if (!token.empty())
        tokens.push_back(token);

    return tokens;
}

vector<string> InfixParser::infixToPostfix(const vector<string>& infix) {
    vector<string> postfix;
    stack<string> s;

    for (const string& token : infix) {
        if (isdigit(token[0])) {
            postfix.push_back(token);
        }
        else if (token == "(") {
            s.push(token);
        }
        else if (token == ")") {
            while (!s.empty() && s.top() != "(") {
                postfix.push_back(s.top());
                s.pop();
            }
            s.pop(); // Discard "("
        }
        else {
            while (!s.empty() && precedence(token[0]) <= precedence(s.top()[0])) {
                postfix.push_back(s.top());
                s.pop();
            }
            s.push(token);
        }
    }

    while (!s.empty()) {
        postfix.push_back(s.top());
        s.pop();
    }

    return postfix;
}

int InfixParser::evaluatePostfix(const vector<string>& postfix) {
    stack<int> s;

    for (const string& token : postfix) {
        if (isdigit(token[0])) {
            s.push(stoi(token));
        }
        else {
            int operand2 = s.top();
            s.pop();
            int operand1 = s.top();
            s.pop();
            switch (token[0]) {
            case '+':
                s.push(operand1 + operand2);
                break;
            case '-':
                s.push(operand1 - operand2);
                break;
            case '*':
                s.push(operand1 * operand2);
                break;
            case '/':
                s.push(operand1 / operand2);
                break;
            case '%':
                s.push(operand1 % operand2);
                break;
            case '^':
                s.push(pow(operand1, operand2));
                break;
            }
        }
    }

    return s.top();
}

int InfixParser::solve(const string& expression) {
    vector<string> tokens = tokenize(expression);
    vector<string> postfix = infixToPostfix(tokens);
    return evaluatePostfix(postfix);
}