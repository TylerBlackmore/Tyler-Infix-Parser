#ifndef INFIXPARSER_H
#define INFIXPARSER_H

#include <iostream>
#include <stack>
#include <string>
#include <vector>

class InfixParser {
public:
    int solve(const std::string& expression);

private:
    bool isOperator(char c);
    int precedence(char op);
    std::vector<std::string> tokenize(const std::string& expression);
    std::vector<std::string> infixToPostfix(const std::vector<std::string>& infix);
    int evaluatePostfix(const std::vector<std::string>& postfix);
};

#endif /* INFIXPARSER_H */


