﻿#include <iostream>
#include <string>
#include "InfixParser.h"
#include "Operator.cpp"
using namespace std;







int main() {
    string infix_expression = "6>5&&4>5";
    int result = andOr(infix_expression);
    cout << "Evaluation result: " << (result) << std::endl;
    cout << (2 % 2 + 2 ^ 2 - 5 * (3 ^ 2));
    return 0;
}

